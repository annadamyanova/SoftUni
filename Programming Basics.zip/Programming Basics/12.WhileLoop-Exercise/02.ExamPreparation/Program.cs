﻿using System;
using System.Diagnostics;

namespace _02.ExamPreparation
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int allowedBadGrades = int.Parse(Console.ReadLine());

            int badGrades = 0;
            double totalScore = 0;
            int gradesCount = 0;
            int problemsCount = 0;
            string lastProblem = string.Empty;

            while (badGrades != allowedBadGrades)
            {                     

                string command = Console.ReadLine();

                if (command == "Enough")
                {
                    Console.WriteLine($"Average score: {(totalScore / gradesCount):f2}");
                    Console.WriteLine($"Number of problems: {problemsCount}");
                    Console.WriteLine($"Last problem: {lastProblem}");
                    return;
                }

                double grade = double.Parse(Console.ReadLine());

                if (grade <= 4)
                {
                    badGrades++;
                }

                totalScore += grade;
                gradesCount++;
                problemsCount++;
                lastProblem = command;
            }

            Console.WriteLine($"You need a break, {badGrades} poor grades.");

        }
    }
}
