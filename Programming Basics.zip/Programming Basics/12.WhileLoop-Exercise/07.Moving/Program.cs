﻿using System;

namespace _07.Moving
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int width = int.Parse(Console.ReadLine());
            int lenght = int.Parse(Console.ReadLine());
            int height = int.Parse(Console.ReadLine());
            string command = Console.ReadLine();

            int availableSpace = width * lenght * height;
            int totalSpace = 0;

            while (command != "Done")
            {
                int carton = int.Parse(command);

                totalSpace += carton;

                if (totalSpace >= availableSpace)
                {
                    break;
                }

                command = Console.ReadLine();
            }

            if (totalSpace > availableSpace)
            {
                Console.WriteLine($"No more free space! You need {Math.Abs(availableSpace - totalSpace)} Cubic meters more.");
            }
            else
            {
                Console.WriteLine($"{Math.Abs(availableSpace - totalSpace)} Cubic meters left.");
            }
        }
    }
}
