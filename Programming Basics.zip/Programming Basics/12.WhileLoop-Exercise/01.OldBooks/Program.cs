﻿using System;

namespace _01.OldBooks
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string favoriteBook = Console.ReadLine();
            string book = Console.ReadLine();

            int booksCount = 0;
            
            while (book != "No More Books")
            {
                if (book == favoriteBook)
                {
                    Console.WriteLine($"You checked {booksCount} books and found it.");
                    return;
                }

                booksCount++;

                book = Console.ReadLine();
            }

            Console.WriteLine("The book you search is not here!");
            Console.WriteLine($"You checked {booksCount} books.");
        }
    }
}
