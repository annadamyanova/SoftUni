﻿using System;

namespace _05.Coins
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double instead = double.Parse(Console.ReadLine()) * 100;

            int firstNum = (int)instead % 10;
            instead /= 10;
            int secondNum = (int)instead % 10;
            instead /= 10;
            int lastNum = (int)instead % 10;

            int coins = 0;

            while (true)
            {

                if (firstNum - 5 >= 0)
                {
                    firstNum -= 5;
                    coins++;
                }
                else if (firstNum - 2 >= 0)
                {
                    firstNum -= 2;
                    coins++;
                }
                else if (firstNum - 1 >= 0)
                {
                    firstNum -= 1;
                    coins++;
                }

                if (secondNum - 5 >= 0)
                {
                    secondNum -= 5;
                    coins++;
                }
                else if (secondNum - 2 >= 0)
                {
                    secondNum -= 2;
                    coins++;
                }
                else if (secondNum - 1 >= 0)
                {
                    secondNum -= 1;
                    coins++;
                }

                if (lastNum - 2 >= 0)
                {
                    lastNum -= 2;
                    coins++;
                }
                else if (lastNum - 1 >= 0)
                {
                    lastNum -= 1;
                    coins++;
                }

                if (firstNum == 0 && secondNum == 0 && lastNum == 0)
                {
                    break;
                }
            }

            Console.WriteLine(coins);
        }
    }
}
