﻿using System;

namespace _06.Cake
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int width = int.Parse(Console.ReadLine());
            int lenght = int.Parse(Console.ReadLine());
            string command = Console.ReadLine();

            int totalPieces = width * lenght;
            int neededPiees = 0;

            while (command != "STOP")
            {
                int pieces = int.Parse(command);

                totalPieces -= pieces;

                if (totalPieces <= 0)
                {
                    neededPiees = Math.Abs(totalPieces);    

                    break;
                }

                command = Console.ReadLine();
            }

            if (totalPieces < 0)
            {
                Console.WriteLine($"No more cake left! You need {neededPiees} pieces more.");
            }
            else
            {
                Console.WriteLine($"{totalPieces} pieces are left.");
            }
        }
    }
}
