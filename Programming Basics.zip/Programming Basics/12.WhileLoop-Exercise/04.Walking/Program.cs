﻿using System;

namespace _04.Walking
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string command = Console.ReadLine();

            int totalSteps = 0;

            while (command != "Going home")
            {
                int steps = int.Parse(command);

                totalSteps += steps;

                if (totalSteps >= 10000)
                {
                    break;
                }

                command = Console.ReadLine();
            }

            if (command == "Going home")
            {
                command = Console.ReadLine();
                int lastSteps = int.Parse(command);

                totalSteps += lastSteps;
            }

            if (totalSteps >= 10000)
            {
                Console.WriteLine("Goal reached! Good job!");
                Console.WriteLine($"{totalSteps-10000} steps over the goal!");
            }
            else
            {
                Console.WriteLine($"{10000-totalSteps} more steps to reach goal.");
            }
        }
    }
}
