﻿using System;

namespace _05.Travelling
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string command = Console.ReadLine();

            while (command != "End")
            {
                double neededMoney = double.Parse(Console.ReadLine());
                double totalSum = 0;

                while (totalSum < neededMoney)
                {
                    double price = double.Parse(Console.ReadLine());

                    totalSum += price;
                }

                Console.WriteLine($"Going to {command}!");

                command = Console.ReadLine();
            }
        }
    }
}
