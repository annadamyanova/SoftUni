﻿using System;

namespace _03.SumPrimeNonPrime
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string command = Console.ReadLine();

            int primeNums = 0;
            int nonPrimeNums = 0;

            while (command != "stop")
            {
                int number = int.Parse(command);

                if (number < 0)
                {
                    Console.WriteLine("Number is negative.");
                }
                else
                {
                    bool isPrime = true;

                    for (int i = 2; i < number; i++)
                    {
                        if (number % i == 0)
                        {
                            isPrime = false;
                            break;
                        }
                    }

                    if (isPrime || number == 1 || number == 0)
                    {
                        primeNums += number;
                    }
                    else
                    {
                        nonPrimeNums += number;
                    }
                }

                command = Console.ReadLine();
            }

            Console.WriteLine($"Sum of all prime numbers is: {primeNums}");
            Console.WriteLine($"Sum of all non prime numbers is: {nonPrimeNums}");
        }
    }
}
