﻿using System;

namespace _02.EqualSumsEvenOddPosition
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1 = int.Parse(Console.ReadLine());
            int num2 = int.Parse(Console.ReadLine()); 

            for (int i = num1; i <= num2; i++)
            {
                string number = i.ToString();

                int evenSum = 0;
                int oddSum = 0;

                for (int j = 0; j < 6; j++)
                {
                    if (j % 2 == 0)
                    {
                        evenSum += int.Parse(number[j].ToString());
                    }
                    else if(j % 2 != 0)
                    {
                        oddSum += int.Parse(number[j].ToString());
                    } 
                }

                if (evenSum == oddSum)
                {
                    Console.Write($"{i} ");
                }
            }
        }
    }
}
