﻿using System;

namespace _06.CinemaTickets
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string filmName = Console.ReadLine();

            int studentCount = 0;
            int standardCount = 0;
            int kidCount = 0;

            while (filmName != "Finish")
            {
                int availableSeats = int.Parse(Console.ReadLine());
                double tickets = 0;

                string ticketType = Console.ReadLine();

                while (ticketType != "End")
                {
                    tickets++;

                    if (ticketType == "student")
                    {
                        studentCount++;
                    }
                    else if(ticketType == "standard")
                    {
                         standardCount++;
                    }
                    else if (ticketType == "kid")
                    {
                        kidCount++;
                    }

                    if (tickets == availableSeats)
                    {
                        break;
                    }

                    ticketType = Console.ReadLine();
                }      

                Console.WriteLine($"{filmName} - {((tickets / availableSeats)* 100):f2}% full.");

                filmName = Console.ReadLine();
            }

            double totalTickets = studentCount + standardCount + kidCount;

            Console.WriteLine($"Total tickets: {totalTickets}");
            Console.WriteLine($"{((studentCount / totalTickets)*100):f2}% student tickets.");
            Console.WriteLine($"{((standardCount / totalTickets)*100):f2}% standard tickets.");
            Console.WriteLine($"{((kidCount / totalTickets)*100):f2}% kids tickets.");
        }
    }
}
