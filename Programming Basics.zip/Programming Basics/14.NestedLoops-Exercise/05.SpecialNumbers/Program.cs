﻿using System;

namespace _05.SpecialNumbers
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            for (int i = 1111; i <= 9999; i++)
            {
                string number = i.ToString();

                bool isSpecial = true;

                for (int j = 0; j < 4; j++)
                {
                    int currNumber = int.Parse(number[j].ToString());

                    if (currNumber == 0 || n % currNumber != 0)
                    {
                        isSpecial = false;
                    }
                }

                if (isSpecial)
                {
                    Console.Write($"{i} ");
                }
            }
        }
    }
}
