﻿using System;

namespace _09.YardGreening
{
    class Program
    {
        static void Main(string[] args)
        {
            double squareMeters = double.Parse(Console.ReadLine());

            double totalPrice = 7.61 * squareMeters;
            double discount = 0.18 * totalPrice;

            double finalSum = totalPrice - discount;

            Console.WriteLine($"The final price is: {finalSum} lv.");
            Console.WriteLine($"The discount is: {discount} lv.");
        }
    }
}
