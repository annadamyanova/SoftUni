﻿using System;

namespace _07.ProjectsCreation
{
    class Program
    {
        static void Main(string[] args)
        {
            string architectName = Console.ReadLine();
            int numberOfprojects = int.Parse(Console.ReadLine());

            Console.WriteLine($"The architect {architectName} will need {numberOfprojects*3} hours to complete {numberOfprojects} project/s.");
        }
    }
}
