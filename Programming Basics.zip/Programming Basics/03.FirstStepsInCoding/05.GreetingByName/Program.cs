﻿using System;

namespace _05.GreetingByName
{
    class Program
    {
        static void Main(string[] args)
        {
            string name = Console.ReadLine();

            Console.WriteLine($"Hello, {name}!");
        }
    }
}
