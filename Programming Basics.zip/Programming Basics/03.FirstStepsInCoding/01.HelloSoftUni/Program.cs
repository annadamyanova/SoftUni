﻿using System;

namespace _01.HelloSoftUni
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello SoftUni");
        }
    }
}
