﻿using System;

namespace _08.PetShop
{
    class Program
    {
        static void Main(string[] args)
        {
            int numOfDogsFood = int.Parse(Console.ReadLine());
            int numOfCatsFood = int.Parse(Console.ReadLine());

            double dogsFoodPrice = 2.50 * numOfDogsFood;
            double catsFoodPrice = 4 * numOfCatsFood;

            double finalPrice = dogsFoodPrice + catsFoodPrice;

            Console.WriteLine($"{finalPrice} lv.");
        }
    }
}
