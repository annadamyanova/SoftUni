﻿using System;

namespace _04.InchesToCentimeters
{
    class Program
    {
        static void Main(string[] args)
        {
            double inches = double.Parse(Console.ReadLine());
            double centimeters = 2.54;

            Console.WriteLine($"{inches*centimeters}");
        }
    }
}
