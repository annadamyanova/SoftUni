﻿using System;

namespace _11.FruitShop
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string fruit = Console.ReadLine();
            string dayOfWeek = Console.ReadLine();
            double count = double.Parse(Console.ReadLine());

            double price = 0;

            switch (dayOfWeek)
            {
                case "Monday":
                case "Tuesday":
                case "Wednesday":
                case "Thursday":
                case "Friday":
                    if (fruit == "banana")
                    {
                        price = count * 2.50;
                    }
                    else if (fruit == "apple")
                    {
                        price = count * 1.20;
                    }
                    else if (fruit == "orange")
                    {
                        price = count * 0.85;
                    }
                    else if (fruit == "grapefruit")
                    {
                        price = count * 1.45;
                    }
                    else if (fruit == "kiwi")
                    {
                        price = count * 2.70;
                    }
                    else if (fruit == "pineapple")
                    {
                        price = count * 5.50;
                    }
                    else if (fruit == "grapes")
                    {
                        price = count * 3.85;
                    }
                    else
                    {
                        Console.WriteLine("error");
                    }
                    break;
                case "Saturday":
                case "Sunday":
                    if (fruit == "banana")
                    {
                        price = count * 2.70;
                    }
                    else if (fruit == "apple")
                    {
                        price = count * 1.25;
                    }
                    else if (fruit == "orange")
                    {
                        price = count * 0.90;
                    }
                    else if (fruit == "grapefruit")
                    {
                        price = count * 1.60;
                    }
                    else if (fruit == "kiwi")
                    {
                        price = count * 3.00;
                    }
                    else if (fruit == "pineapple")
                    {
                        price = count * 5.60;
                    }
                    else if (fruit == "grapes")
                    {
                        price = count * 4.20;
                    }
                    else
                    {
                        Console.WriteLine("error");
                    }
                    break;
                default:
                    Console.WriteLine("error");
                    break;
            }

            if (price > 0)
            {
                Console.WriteLine($"{price:f2}");
            }

        }
    }
}
