﻿using System;

namespace _07.HotelRoom
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string month = Console.ReadLine();
            int numOfNights = int.Parse(Console.ReadLine());

            double priceForApartment = 0;
            double priceForStudio = 0;
                
            if (month == "May" || month == "October")
            {
                priceForStudio = numOfNights * 50;
                priceForApartment = numOfNights * 65;

                if (numOfNights > 14)
                {
                    priceForStudio -= priceForStudio * 0.30;
                    priceForApartment -= priceForApartment * 0.10;
                }
                else if (numOfNights > 7)
                {
                    priceForStudio -= priceForStudio * 0.05;
                }
            }
            else if (month == "June" || month == "September")
            {
                priceForStudio = numOfNights * 75.20;
                priceForApartment = numOfNights * 68.70;

                if (numOfNights > 14)
                {
                    priceForStudio -= priceForStudio * 0.20;
                    priceForApartment -= priceForApartment * 0.10;
                }
            }
            else if (month == "July" || month == "August")
            {
                priceForStudio = numOfNights * 76;
                priceForApartment = numOfNights * 77;

                if (numOfNights > 14)
                {
                    priceForApartment -= priceForApartment * 0.10;
                }
            }

            Console.WriteLine($"Apartment: {priceForApartment:f2} lv.");
            Console.WriteLine($"Studio: {priceForStudio:f2} lv.");
        }
    }
}
