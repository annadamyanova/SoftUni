﻿using System;

namespace _08.OnTimeforТheExam
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int hourOfExam = int.Parse(Console.ReadLine());
            int minutesOfExam = int.Parse(Console.ReadLine());
            int hourOfArrived = int.Parse(Console.ReadLine());
            int minutesOfArrived = int.Parse(Console.ReadLine());

            int totalExamTime = hourOfExam * 60 + minutesOfExam;
            int totalArrivedTime = hourOfArrived * 60 + minutesOfArrived;

            if (totalExamTime < totalArrivedTime)
            {
                int totalTime = totalArrivedTime - totalExamTime;
                int hour = totalTime / 60;
                int minutes = totalTime - (hour * 60);

                Console.WriteLine("Late");

                if (hour <= 0)
                {
                    Console.WriteLine($"{minutes} minutes after the start");
                }
                else
                {
                    Console.WriteLine($"{hour}:{minutes:d2} hours after the start");
                }        
            }
            else if (totalExamTime - totalArrivedTime >= 0 && totalExamTime - totalArrivedTime <= 30)
            {
                int totalTime = totalExamTime - totalArrivedTime;
                int hour = totalTime / 60;
                int minutes = totalTime - (hour * 60);

                Console.WriteLine("On time");

                if (totalArrivedTime == totalExamTime)
                {

                }
                else if (hour <= 0)
                {
                    Console.WriteLine($"{minutes} minutes before the start");
                }
                else
                {
                    Console.WriteLine($"{hour}:{minutes:d2} hours before the start");
                }
            }
            else if (totalExamTime - totalArrivedTime > 30)
            {
                int totalTime = totalExamTime - totalArrivedTime;
                int hour = totalTime / 60;
                int minutes = totalTime - (hour * 60);

                Console.WriteLine("Early");

                if (hour <= 0)
                {
                    Console.WriteLine($"{minutes} minutes before the start");
                }
                else
                {
                    Console.WriteLine($"{hour}:{minutes:d2} hours before the start");
                }
            }
        }
    }
}
