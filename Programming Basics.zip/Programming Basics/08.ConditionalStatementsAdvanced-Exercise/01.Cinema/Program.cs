﻿using System;

namespace _01.Cinema
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string typeOfProjection = Console.ReadLine();
            int rowsCount = int.Parse(Console.ReadLine());
            int colsCount = int.Parse(Console.ReadLine());

            double price = 0;

            if (typeOfProjection == "Premiere")
            {
                price = rowsCount * colsCount * 12.00;
            }
            else if (typeOfProjection == "Normal")
            {
                price = rowsCount * colsCount * 7.50;
            }
            else if (typeOfProjection == "Discount")
            {
                price = rowsCount * colsCount * 5.00;
            }

            if (price > 0)
            {
                Console.WriteLine($"{price:f2} leva");
            }

        }
    }
}
