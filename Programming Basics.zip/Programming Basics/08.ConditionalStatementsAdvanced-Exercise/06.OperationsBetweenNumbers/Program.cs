﻿using System;

namespace _06.OperationsBetweenNumbers
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int firstNum = int.Parse(Console.ReadLine());
            int secondNum = int.Parse(Console.ReadLine());
            char operation = char.Parse(Console.ReadLine());

            double result = 0;

            if (operation == '+' || operation == '-' || operation == '*')
            {
                string evenOrOdd = string.Empty;

                if (operation == '+')
                {
                    result = firstNum + secondNum;
                }
                else if (operation == '-')
                {
                    result = firstNum - secondNum;
                }
                else if (operation == '*')
                {
                    result = firstNum * secondNum;
                }

                if (result % 2 == 0)
                {
                    Console.WriteLine($"{firstNum} {operation} {secondNum} = {result} - even");
                }
                else
                {
                    Console.WriteLine($"{firstNum} {operation} {secondNum} = {result} - odd");
                }
            }
            else if (operation == '/' || operation == '%')
            {
                if (secondNum == 0)
                {
                    Console.WriteLine($"Cannot divide {firstNum} by zero");
                }
                else
                {
                    if (operation == '/')
                    {
                        result = (double)firstNum / secondNum;

                        Console.WriteLine($"{firstNum} / {secondNum} = {result:f2}");
                    }
                    else if (operation == '%')
                    {
                        result = firstNum % secondNum;

                        Console.WriteLine($"{firstNum} % {secondNum} = {result}");
                    }

                }
            }

        }
    }
}
