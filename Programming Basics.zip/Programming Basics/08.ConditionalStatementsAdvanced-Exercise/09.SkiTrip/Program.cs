﻿using System;

namespace _09.SkiTrip
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int days = int.Parse(Console.ReadLine()) - 1;
            string typeOfRoom = Console.ReadLine();
            string grade = Console.ReadLine();

            double price = 0;

            if (typeOfRoom == "room for one person")
            {
                price = 18 * days;
            }
            else if (typeOfRoom == "apartment")
            {
                price = 25 * days;

                if (days < 10)
                {
                    price -= price * 0.30;
                }
                else if (days >= 10 && days <= 15)
                {
                    price -= price * 0.35;
                }
                else if (days > 15)
                {
                    price -= price * 0.50;
                }
            }
            else if (typeOfRoom == "president apartment")
            {
                price = 35 * days;

                if (days < 10)
                {
                    price -= price * 0.10;
                }
                else if (days >= 10 && days <= 15)
                {
                    price -= price * 0.15;
                }
                else if (days > 15)
                {
                    price -= price * 0.20;
                }
            }

            if (grade == "positive")
            {
                price += price * 0.25;
            }
            else if (grade == "negative")
            {
                price -= price * 0.10;
            }

            Console.WriteLine($"{price:f2}");
        }
    }
}
