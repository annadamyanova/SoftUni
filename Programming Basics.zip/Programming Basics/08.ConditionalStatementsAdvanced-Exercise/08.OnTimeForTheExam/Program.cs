﻿using System;

namespace _08.OnTimeForTheExam
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //  93/100

            int hourOfExam = int.Parse(Console.ReadLine());
            int minutesOfExam = int.Parse(Console.ReadLine());  
            int hourOfArrived = int.Parse(Console.ReadLine());
            int minutesOfArrived = int.Parse(Console.ReadLine());

            int earlyMinutes = minutesOfExam - 30;

            int earlyHours = hourOfExam;

            if (earlyMinutes < 0)
            {
                earlyHours--;
                earlyMinutes += 60;
            }

            if ((hourOfExam < hourOfArrived) || (hourOfExam == hourOfArrived && minutesOfExam < minutesOfArrived))
            {
                Console.WriteLine("Late");

                int hoursResult = hourOfArrived - hourOfExam;
                int minutesResult = minutesOfArrived - minutesOfExam;

                if (minutesResult < 0)
                {
                    hoursResult--;
                    minutesResult += 60;
                }

                if (hoursResult > 0)
                {
                    Console.WriteLine($"{hoursResult}:{minutesResult:d2} hours after the start");
                }
                else
                {
                    Console.WriteLine($"{minutesResult} minutes after the start");
                }
            }
            else if ((hourOfArrived < earlyHours) || (hourOfArrived == earlyHours && minutesOfArrived < earlyMinutes))
            {
                Console.WriteLine("Early");

                int hoursResult = hourOfExam - hourOfArrived;
                int minutesResult = minutesOfExam - minutesOfArrived;

                if (minutesResult < 0)
                {
                    hoursResult--;
                    minutesResult += 60;
                }

                if (hoursResult > 0)
                {
                    Console.WriteLine($"{hoursResult}:{minutesResult:d2} hours before the start");
                }
                else
                {
                    Console.WriteLine($"{minutesResult} minutes before the start");
                }
            }
            else if ((hourOfArrived >= earlyHours && hourOfArrived <= hourOfExam) || (minutesOfArrived >= minutesOfExam && minutesOfArrived <= earlyMinutes))
            {
                Console.WriteLine("On time");

                int hoursResult = hourOfExam - hourOfArrived;
                int minutesResult = minutesOfExam - minutesOfArrived;

                if (minutesResult < 0)
                {
                    hoursResult--;
                    minutesResult += 60;
                }

                if (hourOfExam == hourOfArrived && minutesOfExam == minutesOfArrived)
                {
                    Console.WriteLine();
                }
                else if (hoursResult > 0)
                {
                    Console.WriteLine($"{hoursResult}:{minutesResult:d2} hours before the start");
                }
                else
                {
                    Console.WriteLine($"{minutesResult} minutes before the start");
                }
            }
        }
    }
}
