﻿using System;

namespace _03.NewHouse
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string flowersType = Console.ReadLine();
            int flowersCount = int.Parse(Console.ReadLine());
            int budget = int.Parse(Console.ReadLine());

            double price = 0;

            if (flowersType == "Roses")
            {
                price = flowersCount * 5;

                if (flowersCount > 80)
                {
                    price -= price * 0.10;
                }
            }
            else if (flowersType == "Dahlias")
            {
                price = flowersCount * 3.80;

                if (flowersCount > 90)
                {
                    price -= price * 0.15;
                }
            }
            else if (flowersType == "Tulips")
            {
                price = flowersCount * 2.80;

                if (flowersCount > 80)
                {
                    price -= price * 0.15;
                }
            }
            else if (flowersType == "Narcissus")
            {
                price = flowersCount * 3;

                if (flowersCount < 120)
                {
                    price += price * 0.15;
                }
            }
            else if (flowersType == "Gladiolus")
            {
                price = flowersCount * 2.50;

                if (flowersCount < 80)
                {
                    price += price * 0.20;
                }
            }

            if (budget >= price)
            {
                Console.WriteLine($"Hey, you have a great garden with {flowersCount} {flowersType} and {(budget-price):f2} leva left.");
            }
            else
            {
                Console.WriteLine($"Not enough money, you need {(price-budget):f2} leva more.");
            }
        }
    }
}
