﻿using System;

namespace _07.TrekkingMania
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numOfGroups = int.Parse(Console.ReadLine());

            double musala = 0;
            double montBlanc = 0;
            double kilimanjaro = 0;
            double k2 = 0;
            double everest = 0;

            int totalCount = 0;

            for (int i = 0; i < numOfGroups; i++)
            {
                int numOfClimbers = int.Parse(Console.ReadLine());

                totalCount += numOfClimbers;

                if (numOfClimbers <= 5)
                {
                    musala += numOfClimbers;
                }
                else if (numOfClimbers >= 6 && numOfClimbers <= 12)
                {
                    montBlanc += numOfClimbers;
                }
                else if (numOfClimbers >= 13 && numOfClimbers <= 25)
                {
                    kilimanjaro += numOfClimbers;
                }
                else if (numOfClimbers >= 26 && numOfClimbers <= 40)
                {
                    k2 += numOfClimbers;
                }
                else
                {
                    everest += numOfClimbers;
                }
            }

            Console.WriteLine($"{((musala / totalCount) * 100):f2}%");
            Console.WriteLine($"{((montBlanc / totalCount) * 100):f2}%");
            Console.WriteLine($"{((kilimanjaro / totalCount) * 100):f2}%");
            Console.WriteLine($"{((k2 / totalCount) * 100):f2}%");
            Console.WriteLine($"{((everest / totalCount) * 100):f2}%");
        }
    }
}
