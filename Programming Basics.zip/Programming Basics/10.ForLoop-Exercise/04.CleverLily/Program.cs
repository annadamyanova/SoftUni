﻿using System;

namespace _04.CleverLily
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int lilysAge = int.Parse(Console.ReadLine());
            double washingMachinePrice = double.Parse(Console.ReadLine());
            int toyPrice = int.Parse(Console.ReadLine());

            double totalSum = 0;
            int toysCount = 0;

            for (int i = 1; i <= lilysAge; i++)
            {
                if(i % 2 == 0)
                {
                    totalSum += 10 * (i / 2);

                    totalSum -= 1;
                }
                else
                {
                    toysCount++;
                }
            }

            totalSum += (toysCount * toyPrice);

            if (totalSum >= washingMachinePrice)
            {
                Console.WriteLine($"Yes! {(totalSum - washingMachinePrice):f2}");
            }
            else
            {
                Console.WriteLine($"No! {(washingMachinePrice - totalSum):f2}");
            }
        }
    }
}
