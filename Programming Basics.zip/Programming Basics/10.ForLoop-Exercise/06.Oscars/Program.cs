﻿using System;

namespace _06.Oscars
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string nameOfActor = Console.ReadLine();
            double academyPoints = double.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());

            double totalPoints = academyPoints;           

            for (int i = 0; i < n; i++)
            {
                string nameOfAppraiser = Console.ReadLine();
                double pointsOfAppraiser = double.Parse(Console.ReadLine());

                totalPoints += (nameOfAppraiser.Length * pointsOfAppraiser) / 2;

                if (totalPoints >= 1250.5)
                {
                    Console.WriteLine($"Congratulations, {nameOfActor} got a nominee for leading role with {totalPoints:f1}!");
                    return;
                }
            }
          
            Console.WriteLine($"Sorry, {nameOfActor} you need {(1250.5 - totalPoints):f1} more!");
        }
    }
}
