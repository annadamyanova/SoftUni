﻿using System;

namespace _08.TennisRanklist
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numOfТournaments = int.Parse(Console.ReadLine());
            int points = int.Parse(Console.ReadLine());

            int sumOfAddedPoints = 0;
            decimal numOfWins = 0;

            for (int i = 0; i < numOfТournaments; i++)
            {
                string input = Console.ReadLine();

                if (input == "W")
                {
                    sumOfAddedPoints += 2000;
                    numOfWins++;
                }
                else if (input == "F")
                {
                    sumOfAddedPoints += 1200;
                }
                else if (input == "SF")
                {
                    sumOfAddedPoints += 720;
                }

            }

            points += sumOfAddedPoints;
            decimal average = (decimal)sumOfAddedPoints / numOfТournaments;

            Console.WriteLine($"Final points: {points}");
            Console.WriteLine($"Average points: {Math.Floor(average)}");
            Console.WriteLine($"{((numOfWins / numOfТournaments) * 100):f2}%");
        }
    }
}
