﻿using System;

namespace _08.LunchBreak
{
    class Program
    {
        static void Main(string[] args)
        {
            string serieName = Console.ReadLine();
            int episodeDuration = int.Parse(Console.ReadLine());
            int breakDuration = int.Parse(Console.ReadLine());

            double lunchTime = breakDuration * 0.125;
            double breakTime = breakDuration * 0.25;

            double timeLeft = breakDuration - (lunchTime + breakTime);

            if (timeLeft >= episodeDuration)
            {
                Console.WriteLine($"You have enough time to watch {serieName} and left with {Math.Ceiling(timeLeft - episodeDuration)} minutes free time.");
            }
            else
            {
                Console.WriteLine($"You don't have enough time to watch {serieName}, you need {(Math.Ceiling(episodeDuration - timeLeft))} more minutes.");
            }
        }
    }
}
