﻿using System;

namespace _07.Shopping
{
    class Program
    {
        static void Main(string[] args)
        {
            double budget = double.Parse(Console.ReadLine());
            int videoCardsCount = int.Parse(Console.ReadLine());
            int processorsCount = int.Parse(Console.ReadLine());
            int ramMemoryCount = int.Parse(Console.ReadLine());

            double videoCardPrice = videoCardsCount * 250;

            if (videoCardsCount > processorsCount)
            {
                double discount = videoCardPrice * 0.15;
                videoCardPrice -= discount;
            }

            double processorPrice = processorsCount * (videoCardPrice * 0.35);
            double ramMemoryPrice = ramMemoryCount * (videoCardPrice * 0.10);

            double totalSum = videoCardPrice + processorPrice + ramMemoryPrice;

            if (totalSum <= budget)
            {
                Console.WriteLine($"You have {(budget - totalSum):f2} leva left!");
            }
            else
            {
                Console.WriteLine($"Not enough money! You need {Math.Abs(budget - totalSum):f2} leva more!");
            }
        }
    }
}
