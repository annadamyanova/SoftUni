﻿using System;

namespace _05.GodzillaVs.Kong
{
    class Program
    {
        static void Main(string[] args)
        {
            double movieBudget = double.Parse(Console.ReadLine());
            int extrasCount = int.Parse(Console.ReadLine());  // статисти
            double clothingPriceForOneExtra = double.Parse(Console.ReadLine());

            double totalClothingPrice = extrasCount * clothingPriceForOneExtra;
            double decor = movieBudget * 0.10;

            if (extrasCount > 150)
            {
                double discount = totalClothingPrice * 0.10;
                totalClothingPrice -= discount;
            }

            double moneyForClothingAndDecor = totalClothingPrice + decor;

            if (moneyForClothingAndDecor > movieBudget)
            {
                Console.WriteLine("Not enough money!");
                Console.WriteLine($"Wingard needs {Math.Abs(movieBudget - moneyForClothingAndDecor):f2} leva more.");
            }
            else
            {
                Console.WriteLine("Action!");
                Console.WriteLine($"Wingard starts filming with {Math.Abs(movieBudget - moneyForClothingAndDecor):f2} leva left.");
            }
        }
    }
}
