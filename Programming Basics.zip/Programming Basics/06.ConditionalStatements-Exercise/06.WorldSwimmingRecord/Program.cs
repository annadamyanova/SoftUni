﻿using System;

namespace _06.WorldSwimmingRecord
{
    class Program
    {
        static void Main(string[] args)
        {
            double recordTime = double.Parse(Console.ReadLine());
            double distanceInMeters = double.Parse(Console.ReadLine());
            double timeInSecondsForOneMeter = double.Parse(Console.ReadLine());

            double neededTime = distanceInMeters * timeInSecondsForOneMeter; 
            double delay = (Math.Floor(distanceInMeters / 15)) * 12.5;

            double totalTime = neededTime + delay;

            if (totalTime < recordTime)
            {
                Console.WriteLine($"Yes, he succeeded! The new world record is {totalTime:f2} seconds.");
            }
            else if(totalTime >= recordTime)
            {
                Console.WriteLine($"No, he failed! He was {(totalTime - recordTime):f2} seconds slower.");
            }
        }
    }
}
