﻿using System;

namespace _04.ToyShop
{
    class Program
    {
        static void Main(string[] args)
        {
            double tripPrice = double.Parse(Console.ReadLine());
            int puzzlesCount = int.Parse(Console.ReadLine());
            int dollsCount = int.Parse(Console.ReadLine());
            int bearsCount = int.Parse(Console.ReadLine());
            int minionsCount = int.Parse(Console.ReadLine());
            int trucksCount = int.Parse(Console.ReadLine());

            double puzzlesPrice = puzzlesCount * 2.60;
            double dollsPrice = dollsCount * 3;
            double bearsPrice = bearsCount * 4.10;
            double minionsPrice = minionsCount * 8.20;
            double trucksPrice = trucksCount * 2;

            int toysCount = puzzlesCount + dollsCount + bearsCount + minionsCount + trucksCount;
            double totalToysPrice = puzzlesPrice + dollsPrice + bearsPrice + minionsPrice + trucksPrice;

            if (toysCount >= 50)
            {
                double discount = totalToysPrice * 0.25;
                totalToysPrice -= discount;
            }

            double rent = totalToysPrice * 0.10;
            totalToysPrice -= rent;

            if (totalToysPrice >= tripPrice)
            {
                Console.WriteLine($"Yes! {(totalToysPrice - tripPrice):f2} lv left.");
            }
            else
            {
                Console.WriteLine($"Not enough money! {(tripPrice - totalToysPrice):f2} lv needed.");
            }
        }
    }
}
