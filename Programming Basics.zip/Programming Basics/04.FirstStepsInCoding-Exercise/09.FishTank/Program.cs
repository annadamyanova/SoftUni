﻿using System;

namespace _09.FishTank
{
    class Program
    {
        static void Main(string[] args)
        {
            int lenght = int.Parse(Console.ReadLine());
            int width = int.Parse(Console.ReadLine());
            int height = int.Parse(Console.ReadLine());
            double percentage = double.Parse(Console.ReadLine()) / 100;

            double totalVolume = (lenght / 10.0) * (width / 10.0) * (height / 10.0);
            double volume = totalVolume * (1 - percentage);

            Console.WriteLine(volume);
        }
    }
}
