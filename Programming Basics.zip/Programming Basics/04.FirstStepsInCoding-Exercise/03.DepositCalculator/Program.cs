﻿using System;

namespace _03.DepositCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            //сума = депозирана сума  + срок на депозита * ((депозирана сума * годишен лихвен процент ) / 12)

            double amountDeposited = double.Parse(Console.ReadLine());
            int depositeTerm = int.Parse(Console.ReadLine());
            double annualRate = double.Parse(Console.ReadLine()) / 100;

            double sum = amountDeposited + depositeTerm * ((amountDeposited * annualRate) / 12);

            Console.WriteLine(sum);

        }
    }
}
