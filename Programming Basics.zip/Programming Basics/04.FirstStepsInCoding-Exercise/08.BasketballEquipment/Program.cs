﻿using System;

namespace _08.BasketballEquipment
{
    class Program
    {
        static void Main(string[] args)
        {
            int annualTax = int.Parse(Console.ReadLine());

            double sneakers = annualTax - (annualTax * 0.40);
            double clothes = sneakers - (sneakers * 0.20);
            double ball = clothes * 0.25;   // 1/4
            double accessories = ball * 0.20;  // 1/5

            double totalSum = annualTax + sneakers + clothes + ball + accessories;

            Console.WriteLine(totalSum);
        }
    }
}
