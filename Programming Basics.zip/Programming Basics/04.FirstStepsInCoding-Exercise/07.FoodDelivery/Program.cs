﻿using System;

namespace _07.FoodDelivery
{
    class Program
    {
        static void Main(string[] args)
        {
            int chickenCount = int.Parse(Console.ReadLine());
            int fishCount = int.Parse(Console.ReadLine());
            int vegeterianCount = int.Parse(Console.ReadLine());

            double totalPrice = (chickenCount * 10.35) + (fishCount * 12.40) + (vegeterianCount * 8.15);
            double dessert = totalPrice * 0.20;

            double finalSum = totalPrice + dessert + 2.50;

            Console.WriteLine(finalSum);
        }
    }
}
