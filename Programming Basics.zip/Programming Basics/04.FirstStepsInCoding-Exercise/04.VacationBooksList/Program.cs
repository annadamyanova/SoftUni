﻿using System;

namespace _04.VacationBooksList
{
    class Program
    {
        static void Main(string[] args)
        {
            int pagesCount = int.Parse(Console.ReadLine());
            int pagesPerHour = int.Parse(Console.ReadLine());
            int days = int.Parse(Console.ReadLine());

            int hoursCount = (pagesCount / pagesPerHour) / days;

            Console.WriteLine(hoursCount);
        }
    }
}
