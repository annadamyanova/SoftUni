﻿using System;

namespace _05.SuppliesForSchool
{
    class Program
    {
        static void Main(string[] args)
        {
            int pensCount = int.Parse(Console.ReadLine());
            int markersCount = int.Parse(Console.ReadLine());
            int litersOfDetergent = int.Parse(Console.ReadLine());
            int percentageSale = int.Parse(Console.ReadLine());

            decimal pensPrice = pensCount * 5.80m;
            decimal markersPrice = markersCount * 7.20m;
            decimal detergentPrice = litersOfDetergent * 1.20m;

            decimal percentage = percentageSale / 100m;

            decimal totalMaterials = pensPrice + markersPrice + detergentPrice;
            decimal priceWithSale = totalMaterials - (totalMaterials * percentage);

            Console.WriteLine(priceWithSale);
        }
    }
}
