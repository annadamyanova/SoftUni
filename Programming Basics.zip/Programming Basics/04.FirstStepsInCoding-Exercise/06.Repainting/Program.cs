﻿using System;

namespace _06.Repainting
{
    class Program
    {
        static void Main(string[] args)
        {
            int neededNylon = int.Parse(Console.ReadLine());
            int neededPaint = int.Parse(Console.ReadLine());
            int thinnerCount = int.Parse(Console.ReadLine());  //разредител
            int hours = int.Parse(Console.ReadLine());

            double nylon = (neededNylon + 2) * 1.50;
            double paint = (neededPaint + (neededPaint * 0.10)) * 14.50;
            double thinner = thinnerCount * 5.00;

            double totalSum = nylon + paint + thinner + 0.40;
            double workMansSum = (totalSum * 0.30) * hours;

            Console.WriteLine(totalSum + workMansSum);
        }
    }
}
