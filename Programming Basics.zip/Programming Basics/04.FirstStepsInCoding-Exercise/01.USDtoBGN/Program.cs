﻿using System;

namespace _01.USDtoBGN
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal usd = decimal.Parse(Console.ReadLine());

            decimal bgn = usd * 1.79549m;

            Console.WriteLine(bgn);
        }
    }
}
