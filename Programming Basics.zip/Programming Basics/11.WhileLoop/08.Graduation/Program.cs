﻿using System;

namespace _08.Graduation
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string nameOfStudent = Console.ReadLine();
            double grades = double.Parse(Console.ReadLine());

            double sum = 0;
            int badGrades = 0;
            int grade = 0;

            while (true)
            {
                if (grades < 4)
                {
                    badGrades++;
                }

                if (badGrades == 2)
                {
                    Console.WriteLine($"{nameOfStudent} has been excluded at {grade} grade");
                    return;
                }

                grade++;
                sum += grades;

                if (grade == 12)
                {
                    break;
                }

                grades = double.Parse(Console.ReadLine());
            }


            Console.WriteLine($"{nameOfStudent} graduated. Average grade: {(sum / 12):f2}");
        }
    }
}
