﻿using System;

namespace _06.MaxNumber
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();

            int biggest = int.Parse(input);

            while (input != "Stop")
            {
                int number = int.Parse(input);

                if (number > biggest)
                {
                    biggest = number;
                }

                input = Console.ReadLine();
            }

            Console.WriteLine(biggest);
        }
    }
}
