﻿using System;

namespace _07.MinNumber
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();

            int smallest = int.Parse(input);

            while (input != "Stop")
            {
                int number = int.Parse(input);

                if (number < smallest)
                {
                    smallest = number;
                }

                input = Console.ReadLine();
            }

            Console.WriteLine(smallest);
        }
    }
}
