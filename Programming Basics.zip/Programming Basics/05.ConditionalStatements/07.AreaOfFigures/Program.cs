﻿using System;

namespace _07.AreaOfFigures
{
    class Program
    {
        static void Main(string[] args)
        {
            string figuere = Console.ReadLine();
            double area = 0;

            if (figuere == "square")
            {
                double side = double.Parse(Console.ReadLine());

                area = side * side;
            }
            else if (figuere == "rectangle")
            {
                double sideA = double.Parse(Console.ReadLine());
                double sideB = double.Parse(Console.ReadLine());

                area = sideA * sideB;
            }
            else if (figuere == "circle")
            {
                double radius = double.Parse(Console.ReadLine());

                area = (radius * radius) * Math.PI;
            }
            else if (figuere == "triangle")
            {
                double side = double.Parse(Console.ReadLine()); ;
                double height = double.Parse(Console.ReadLine());

                area = (side * height) / 2;
            }

            Console.WriteLine($"{area:f3}");
        }
    }
}
